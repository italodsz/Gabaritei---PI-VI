# Resultado da revisão do recomendador ENEM

## Correções aplicadas

- `vetorizar.py` agora lê `area`, `question`, `answer` e o `id` estável do JSONL v1.2.1. A coleção Chroma antiga, com vetores iguais, foi preservada e não é consultada pelo novo código.
- O índice novo contém 2.693 questões `ready_text=true`, TF-IDF de palavras e caracteres e embeddings MiniLM sobre o texto real. São 2.693 IDs únicos e 2.681 vetores MiniLM únicos; as repetições restantes decorrem de conteúdo repetido ou recortes iguais, sem a degeneração anterior de 3.069 vetores idênticos.
- Descrições visuais são inseridas no texto quando há `[[placeholder]]`. Questões dependentes de imagem sem texto utilizável são excluídas.
- A busca filtra pela mesma área, exclui a questão consultada e a mesma família textual, usa habilidade apenas como preferência e combina MiniLM com TF-IDF. Só devolve candidatos com similaridade MiniLM >= 0,60 e TF-IDF >= 0,10, no máximo três por padrão.
- Os dois índices registram hash do dataset e versão do pipeline para detectar artefatos desatualizados. O ambiente Python e as dependências estão na pasta do projeto.

## Avaliação temporal

Consultas de 2023/2024 foram comparadas com 2.330 questões de 2009–2022. A tabela mede somente as sugestões aceitas pelo limiar; "mesma habilidade" e "mesmo tópico previsto" são proxies, não juízos humanos de relevância.

| Ano | Consultas com alguma sugestão | Sugestões | Mesma habilidade oficial | Mesmo tópico previsto |
|---|---:|---:|---:|---:|
| 2023 | 80/180 | 153 | 18,3% | 44,6% |
| 2024 | 85/183 | 170 | 31,8% | 51,0% |

A base antiga do Chroma não produz ranking útil: armazenou 3.069 cópias do mesmo texto vazio e do mesmo vetor. Para referência, o baseline lexical por área, sem limiar e com cinco sugestões por consulta, teve em 2024 15,5% de mesma habilidade e 42,3% de mesmo tópico previsto. Essa comparação muda a cobertura e o número de sugestões, então não mede um ganho de precisão humana.

## Limite observado

Uma consulta sobre formação dos Estados ainda retorna entre as primeiras sugestões um item sobre urbanização. Outra sobre volume de embalagem pode recuperar itens sobre capacidade com operação matemática diferente. Os tópicos automáticos do dataset também contêm erros; por exemplo, uma questão de química aparece rotulada como ecologia. O sistema novo serve para busca assistida e triagem, mas não está validado para escolher automaticamente a próxima questão do aluno.

## Próximo teste para medir precisão

Separar ao menos 50 consultas, com candidatos dos dois sistemas, e pedir a revisores de conteúdo uma avaliação cega de pertinência ao conceito, operação exigida e nível. Medir precisão@3 e taxa de consultas sem sugestão útil por área; ajustar os limiares somente na validação e confirmar em um conjunto de teste separado. Revisar ou substituir a taxonomia automática antes de usá-la como filtro obrigatório.

## Execução

Na pasta `C:\Users\joao.pedro\Downloads\dataset_gabaritei_curated_v1_2_1_core`, veja `README_RECOMENDADOR.md`. O comando de consulta é:

```powershell
.venv\Scripts\python.exe vetorizar.py recommend --question-id gq_fe98fbce5f01e83b2fafee8b
```
