"""Indexação e recomendação lexical de questões ENEM.

Uso: py vetorizar.py index | evaluate | recommend --question-id ID
O índice novo é independente da coleção Chroma anterior, que contém vetores iguais.
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path

import joblib
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "dataset_gabaritei_curated_v1_2_1_core" / "dataset_gabaritei_curated_v1_2_1_core" / "data" / "questions.jsonl"
INDEX = ROOT / "enem_tfidf_v2.joblib"
SEMANTIC_INDEX = ROOT / "enem_minilm_v2.npz"
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
PIPELINE_VERSION = "v2.1-descriptions-last400"


def source_hash():
    return hashlib.sha256(DATA.read_bytes()).hexdigest()


def load_questions():
    with DATA.open(encoding="utf-8") as source:
        rows = [json.loads(line) for line in source if line.strip()]
    ids = [row["id"] for row in rows]
    if len(ids) != len(set(ids)):
        raise ValueError("IDs duplicados no dataset")
    return [row for row in rows if row.get("ready_text") and row.get("question", "").strip()]


def text_of(row):
    # Tópicos previstos não entram no vetor: são regras não revisadas.
    text = row["question"]
    if "[[placeholder]]" in text:
        descriptions = " ".join(d.get("text", "") for d in row.get("descriptions", []))
        text = text.replace("[[placeholder]]", descriptions, 1).replace("[[placeholder]]", " ")
    return text


def semantic_text(row):
    text = text_of(row)
    return text[-400:]


def build(rows):
    texts = [text_of(row) for row in rows]
    word = TfidfVectorizer(strip_accents="unicode", lowercase=True, ngram_range=(1, 2),
                           min_df=2, max_df=0.9, sublinear_tf=True, max_features=90000)
    char = TfidfVectorizer(strip_accents="unicode", lowercase=True, analyzer="char_wb",
                           ngram_range=(3, 5), min_df=3, max_df=0.9, sublinear_tf=True,
                           max_features=120000)
    return {"rows": rows, "word": word, "char": char, "source_hash": source_hash(),
            "pipeline_version": PIPELINE_VERSION,
            "word_matrix": word.fit_transform(texts),
            "char_matrix": char.fit_transform(texts)}


def rank(index, query, *, limit=5, same_skill=True, topic_boost=0.0):
    rows = index["rows"]
    eligible = np.array([
        i for i, item in enumerate(rows)
        if item["area"] == query["area"]
        and item["id"] != query["id"]
        and item.get("content_family_id") != query.get("content_family_id")
        and (not same_skill or not query.get("skill") or item.get("skill") == query["skill"])
    ], dtype=int)
    if len(eligible) == 0:
        return []
    text = text_of(query)
    word_scores = (index["word_matrix"][eligible] @ index["word"].transform([text]).T).toarray().ravel()
    char_scores = (index["char_matrix"][eligible] @ index["char"].transform([text]).T).toarray().ravel()
    scores = 0.7 * word_scores + 0.3 * char_scores
    topic = (query.get("pedagogy") or {}).get("topic_predicted")
    if topic_boost and topic:
        scores += topic_boost * np.array([
            (rows[i].get("pedagogy") or {}).get("topic_predicted") == topic for i in eligible
        ], dtype=float)
    order = np.argsort(-scores, kind="stable")[:limit]
    return [(rows[eligible[pos]], float(scores[pos])) for pos in order]


def semantic_index(rows):
    try:
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise SystemExit("Instale sentence-transformers para usar MiniLM") from exc
    model = SentenceTransformer(MODEL_NAME)
    vectors = model.encode([semantic_text(row) for row in rows], batch_size=32,
                           normalize_embeddings=True, show_progress_bar=True)
    np.savez_compressed(SEMANTIC_INDEX, ids=np.array([row["id"] for row in rows]),
                        vectors=vectors, source_hash=source_hash(), pipeline_version=PIPELINE_VERSION)
    print(f"MiniLM salvo: {SEMANTIC_INDEX}; {len(rows)} vetores gerados para textos reais")


def rank_hybrid(index, query, semantic, model, *, limit=5, min_semantic=0.60, min_lexical=0.10):
    rows = index["rows"]
    if not np.array_equal(semantic["ids"], np.array([row["id"] for row in rows])):
        raise ValueError("Índices TF-IDF e MiniLM têm IDs/ordem diferentes; reconstrua ambos")
    eligible = np.array([i for i, row in enumerate(rows)
                         if row["area"] == query["area"] and row["id"] != query["id"]
                         and row.get("content_family_id") != query.get("content_family_id")], dtype=int)
    if not len(eligible):
        return []
    text = text_of(query)
    word = (index["word_matrix"][eligible] @ index["word"].transform([text]).T).toarray().ravel()
    char = (index["char_matrix"][eligible] @ index["char"].transform([text]).T).toarray().ravel()
    lexical = 0.7 * word + 0.3 * char
    query_vector = model.encode([semantic_text(query)], normalize_embeddings=True)[0]
    meaning = semantic["vectors"][eligible] @ query_vector
    skill = query.get("skill")
    skill_bonus = np.array([row.get("skill") == skill for row in (rows[i] for i in eligible)], dtype=float) * (0.025 if skill else 0)
    score = 0.6 * meaning + 0.4 * np.minimum(lexical * 2, 1) + skill_bonus
    valid = np.flatnonzero((meaning >= min_semantic) & (lexical >= min_lexical))
    order = valid[np.argsort(-score[valid], kind="stable")[:limit]]
    return [(rows[eligible[pos]], float(score[pos]), float(meaning[pos]), float(lexical[pos])) for pos in order]


def evaluate():
    rows = load_questions()
    train = [row for row in rows if row["year"] <= 2022]
    index = build(train)
    print(f"Candidatas: {len(train)}; validação 2023; teste 2024")
    for name, same_skill, topic_boost in [
        ("area", False, 0.0),
        ("area+habilidade", True, 0.0),
        ("area+habilidade+topico", True, 0.08),
    ]:
        for year in (2023, 2024):
            queries = [row for row in rows if row["year"] == year]
            results = [(q, rank(index, q, same_skill=same_skill, topic_boost=topic_boost)) for q in queries]
            pairs = [(q, r) for q, hits in results for r, _ in hits]
            skill_pairs = [(q, r) for q, r in pairs if q.get("skill")]
            topic_pairs = [(q, r) for q, r in pairs if (q.get("pedagogy") or {}).get("topic_predicted")]
            print(json.dumps({"policy": name, "year": year, "queries": len(queries),
                              "returned": len(pairs),
                              "same_skill": round(sum(q["skill"] == r.get("skill") for q, r in skill_pairs) / len(skill_pairs), 3) if skill_pairs else None,
                              "same_topic_predicted": round(sum(q["pedagogy"]["topic_predicted"] == r["pedagogy"]["topic_predicted"] for q, r in topic_pairs) / len(topic_pairs), 3) if topic_pairs else None}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["index", "semantic-index", "evaluate", "recommend"])
    parser.add_argument("--question-id")
    parser.add_argument("--limit", type=int, default=3)
    args = parser.parse_args()
    if args.command == "evaluate":
        evaluate()
        return
    if args.command == "index":
        rows = load_questions()
        index = build(rows)
        joblib.dump(index, INDEX, compress=3)
        print(f"Índice salvo: {INDEX}; {len(rows)} questões text-ready; IDs únicos: {len(set(r['id'] for r in rows))}")
        return
    if args.command == "semantic-index":
        semantic_index(load_questions())
        return
    if not args.question_id:
        parser.error("recommend requer --question-id")
    index = joblib.load(INDEX)
    if index.get("source_hash") != source_hash() or index.get("pipeline_version") != PIPELINE_VERSION:
        parser.error("Dataset ou pipeline mudou; reconstrua os dois índices")
    query = next((row for row in index["rows"] if row["id"] == args.question_id), None)
    if query is None:
        parser.error("Questão não encontrada no índice")
    if not SEMANTIC_INDEX.exists():
        parser.error("Crie o índice MiniLM com: py vetorizar.py semantic-index")
    from sentence_transformers import SentenceTransformer
    with np.load(SEMANTIC_INDEX) as semantic:
        if str(semantic["source_hash"]) != source_hash() or str(semantic["pipeline_version"]) != PIPELINE_VERSION:
            parser.error("Dataset ou pipeline mudou; reconstrua o índice MiniLM")
        model = SentenceTransformer(MODEL_NAME)
        hits = rank_hybrid(index, query, semantic, model, limit=args.limit)
    if not hits:
        print("Sem recomendação confiável para esta questão.")
    for row, score, meaning, lexical in hits:
        print(json.dumps({"id": row["id"], "area": row["area"], "skill": row.get("skill"),
                          "topic_predicted_unreviewed": (row.get("pedagogy") or {}).get("topic_predicted"),
                          "year": row["year"], "co_item": row["co_item"],
                          "score_hybrid": round(score, 4), "similarity_minilm": round(meaning, 4),
                          "similarity_tfidf": round(lexical, 4), "excerpt": row["question"][-300:]}, ensure_ascii=False))


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    main()
