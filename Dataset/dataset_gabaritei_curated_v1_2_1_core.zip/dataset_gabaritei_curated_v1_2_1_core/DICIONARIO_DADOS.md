# Dicionário de dados v1.2.1

Os campos de v1.1.0 permanecem. `answer`, `area`, `skill`, `tri`, abandono e identidade são oficiais e governados pela tabela do INEP. `family_id` identifica a identidade oficial; `content_family_id` agrupa textos literalmente iguais sem fundir `co_item` diferentes.

## Novos metadados pedagógicos

`pedagogy.topic_predicted` e `subtopic_predicted` são rótulos por regras; `topic_evidence_terms` registra os termos disparadores; `topic_confidence` é confiança heurística, não probabilidade calibrada; `cognitive_operation_predicted` e `content_mode` descrevem a forma da tarefa; `skill_predicted` permanece nulo quando não existe classificador validado; `review_status=rule_generated_unreviewed` impede confusão com revisão humana.

## Estados importantes

`ready_text=false` significa que a questão depende de elemento visual ainda sem descrição utilizável. `ready_multimodal=true` refere-se ao dataset completo; neste pacote core os binários não estão incluídos. `license.public_review_required=true` bloqueia publicação automática. `application_type=second_application` identifica as 221 questões adicionais de 2015–2016 reclassificadas na v1.2.0.


## Campos corretivos da v1.2.1

`ready_text_basis` explica por que um item reparado pode ou não ser usado sem a imagem. `correction_notes` registra correções pontuais de vínculo. Descrições com `origin=model_assisted_source_verified_unreviewed` foram conferidas contra o arquivo-fonte, mas não equivalem a revisão humana.
