#!/usr/bin/env python3
"""Independent regression and integrity validator for Gabaritei v1.2.1."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]


def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


errors = []
manifest = json.loads((ROOT / "manifest_sha256.json").read_text(encoding="utf-8"))
for rel, meta in manifest.items():
    path = ROOT / rel
    if not path.is_file():
        errors.append(f"missing:{rel}")
    elif path.stat().st_size != meta["bytes"] or digest(path) != meta["sha256"]:
        errors.append(f"digest:{rel}")

questions = rows(ROOT / "data/questions.jsonl")
text_ready = rows(ROOT / "data/questions_text_ready.jsonl")
pending = rows(ROOT / "data/pending_review.jsonl")
assets = rows(ROOT / "data/assets.jsonl")
descriptions = rows(ROOT / "data/descriptions.jsonl")
by_key = {(int(q["year"]), str(q["co_item"])): q for q in questions}

expected_markers = {
    (2019, "111593"): "Um comerciante, que vende somente pastel",
    (2019, "111518"): "Nos seis cômodos de uma casa",
    (2020, "84184"): "Por qual motivo ocorre a eletrização",
    (2020, "62745"): "Uma pessoa percebe que a bateria de seu veículo",
    (2020, "112080"): "Finally, Aisha finished with her customer",
}
for key, marker in expected_markers.items():
    if key not in by_key:
        errors.append(f"repaired_missing:{key}")
    elif marker not in by_key[key]["question"]:
        errors.append(f"wrong_text_link:{key}")

if len(questions) != 3069:
    errors.append(f"canonical_count:{len(questions)}")
if len(text_ready) != 2693:
    errors.append(f"text_ready_count:{len(text_ready)}")
if len(pending) != 84:
    errors.append(f"pending_count:{len(pending)}")
if len({q["id"] for q in questions}) != len(questions):
    errors.append("duplicate_id")
if len(by_key) != len(questions):
    errors.append("duplicate_year_co_item")
if any(q.get("release") != "1.2.1" for q in questions):
    errors.append("wrong_release")
if any(q.get("is_abandoned_official") for q in questions):
    errors.append("abandoned_in_canonical")
if any([o.get("label") for o in q.get("options", [])] != list("ABCDE") for q in questions):
    errors.append("invalid_options")
if len(by_key[(2020, "60072")].get("assets", [])) != 1:
    errors.append("question_94_asset_leak")
if by_key[(2019, "111593")].get("ready_text") is not False:
    errors.append("question_178_should_not_be_text_ready")
if any((int(r.get("year", -1)), str(r.get("co_item", ""))) in expected_markers for r in pending):
    errors.append("repaired_item_still_pending")

referenced_assets = {a["id"] for q in questions for a in q.get("assets", [])}
global_assets = {a["id"] for a in assets}
if referenced_assets != global_assets:
    errors.append(f"asset_index_mismatch:referenced={len(referenced_assets)} global={len(global_assets)}")
referenced_desc = {d["id"] for q in questions for d in q.get("descriptions", [])}
if referenced_desc != {d["id"] for d in descriptions}:
    errors.append("description_index_mismatch")

split_counts = Counter(q["split"] for q in questions)
text_split_counts = Counter(q["split"] for q in text_ready)
if split_counts != Counter({"train": 2706, "validation": 180, "test": 183}):
    errors.append(f"split_counts:{dict(split_counts)}")
if text_split_counts != Counter({"train": 2330, "validation": 180, "test": 183}):
    errors.append(f"text_split_counts:{dict(text_split_counts)}")

official = defaultdict(list)
for row in csv.DictReader((ROOT / "sources/itens_prova_inep_2009_2025.csv").open(encoding="utf-8")):
    official[(row["ano"], row["co_item"])].append(row)
for q in questions:
    matched = False
    for row in official[(str(q["year"]), str(q["co_item"]))]:
        tri = q.get("tri") or {}
        try:
            matched = (
                row["tx_gabarito"] == q["answer"] and row["sg_area"] == q["area"] and row["in_item_aban"] == "0"
                and row["co_habilidade"] == (q.get("skill") or "")
                and all(abs(float(tri[k]) - float(row[f"nu_param_{k}"])) <= 1e-5 for k in "abc")
            )
        except (TypeError, ValueError):
            matched = False
        if matched:
            break
    if not matched:
        errors.append(f"official_mismatch:{q['year']}:{q['co_item']}")

report = {
    "status": "PASS" if not errors else "FAIL",
    "errors": errors,
    "counts": {
        "manifest_files": len(manifest), "canonical": len(questions), "text_ready": len(text_ready),
        "pending": len(pending), "assets": len(assets), "descriptions": len(descriptions),
        "splits": dict(split_counts), "text_splits": dict(text_split_counts),
    },
}
print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
