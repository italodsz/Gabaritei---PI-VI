#!/usr/bin/env python3
"""Independent integrity validator for Gabaritei curated v1.2.0 core."""

from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]


def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


errors = []
manifest = json.loads((ROOT / "manifest_sha256.json").read_text(encoding="utf-8"))
for rel, meta in manifest.items():
    path = ROOT / rel
    if not path.is_file():
        errors.append(f"missing:{rel}")
    elif path.stat().st_size != meta["bytes"] or digest(path) != meta["sha256"]:
        errors.append(f"digest:{rel}")

questions = rows(ROOT / "data/questions.jsonl")
text_ready = rows(ROOT / "data/questions_text_ready.jsonl")
pending = rows(ROOT / "data/pending_review.jsonl")
excluded = rows(ROOT / "data/excluded_official_abandoned.jsonl")

if len(questions) != 3066:
    errors.append(f"canonical_count:{len(questions)}")
if len(text_ready) != 2691:
    errors.append(f"text_ready_count:{len(text_ready)}")
if len(pending) != 87:
    errors.append(f"pending_count:{len(pending)}")
if len(excluded) != 49:
    errors.append(f"excluded_count:{len(excluded)}")
if len({q["id"] for q in questions}) != len(questions):
    errors.append("duplicate_id")
if len({(q["year"], q["co_item"]) for q in questions}) != len(questions):
    errors.append("duplicate_year_co_item")
if not {q["id"] for q in text_ready}.issubset({q["id"] for q in questions}):
    errors.append("text_ready_not_subset")
if any(q.get("release") != "1.2.0" for q in questions):
    errors.append("wrong_release")
if any(q.get("application_type") == "extra_application_unconfirmed" for q in questions):
    errors.append("unconfirmed_application")
if any(q.get("is_abandoned_official") for q in questions):
    errors.append("abandoned_in_canonical")
if any([o.get("label") for o in q.get("options", [])] != list("ABCDE") for q in questions):
    errors.append("invalid_options")
if any((q["year"], q["co_item"]) in {(2019, "111518"), (2020, "84184"), (2020, "112080")} for q in questions):
    errors.append("rejected_text_linkage_in_canonical")

split_counts = Counter(q["split"] for q in questions)
text_split_counts = Counter(q["split"] for q in text_ready)
if split_counts != Counter({"train": 2703, "validation": 180, "test": 183}):
    errors.append(f"split_counts:{dict(split_counts)}")
if text_split_counts != Counter({"train": 2328, "validation": 180, "test": 183}):
    errors.append(f"text_split_counts:{dict(text_split_counts)}")

report = {
    "status": "PASS" if not errors else "FAIL",
    "errors": errors,
    "counts": {
        "manifest_files": len(manifest), "canonical": len(questions), "text_ready": len(text_ready),
        "pending": len(pending), "excluded": len(excluded), "splits": dict(split_counts),
        "text_splits": dict(text_split_counts),
    },
}
print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
raise SystemExit(0 if not errors else 1)
