#!/usr/bin/env python3
"""Build the conservative Gabaritei v1.2.0 core release from frozen v1.1.0.

This release does not train or create embeddings.  It improves provenance,
application classification, deterministic pedagogical tags and audit queues.
"""

from __future__ import annotations

import csv
import hashlib
import html
import json
import re
import shutil
import unicodedata
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


HERE = Path(__file__).resolve().parent
SRC = HERE.parent / "current_v110" / "dataset_gabaritei_combined_v1_1_0_core"
OUT = HERE / "dataset_gabaritei_curated_v1_2_0_core"
ZIP = HERE / "dataset_gabaritei_curated_v1_2_0_core.zip"
SOURCE_2025 = HERE.parent / "sources" / "simulador_enem"
VERSION = "1.2.0"

# These three records passed the official-metadata check, but their text was
# demonstrably copied from a neighbouring/language-alternative official item.
# They are removed from the canonical set and retained in the pending queue.
TEXT_LINKAGE_REJECTIONS = {
    (2019, "111518"): "text and visual from official item 83994 (question 180) were duplicated onto question 179",
    (2020, "84184"): "text from official item 79124 (blue question 92) was duplicated onto blue question 91",
    (2020, "112080"): "Spanish item 62053 text was duplicated onto the English-language alternative item 112080",
}


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def pt_int(value: int) -> str:
    return f"{value:,}".replace(",", ".")


def clean_text(text: str) -> str:
    text = html.unescape(text or "")
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"[\u200b-\u200f\u2060\ufeff]", "", text)
    return re.sub(r"\s+", " ", text).strip()


def normalized(text: str) -> str:
    text = clean_text(text).lower()
    text = "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def full_text(q: dict) -> str:
    return "\n".join([q.get("question", "")] + [o.get("text", "") or "" for o in q.get("options", [])])


PEDAGOGY_RULES = {
    "CH": [
        ("História", "Brasil e formação histórica", ["brasil", "colonial", "imperio", "republica", "escrav", "independencia"]),
        ("História", "História mundial", ["revolucao", "guerra mundial", "idade media", "antiguidade", "renascimento"]),
        ("Geografia", "Espaço, território e população", ["territorio", "urbaniza", "migracao", "populacao", "fronteira", "globalizacao"]),
        ("Geografia", "Ambiente e recursos naturais", ["clima", "relevo", "vegetacao", "rio", "bacia", "desmatamento"]),
        ("Sociologia", "Sociedade, cultura e trabalho", ["sociedade", "cultura", "trabalho", "desigualdade", "movimento social"]),
        ("Filosofia", "Ética, política e conhecimento", ["etica", "moral", "filosof", "razao", "conhecimento", "democracia"]),
        ("Economia", "Produção e relações econômicas", ["economia", "industria", "agricultura", "capital", "mercado", "producao"]),
    ],
    "CN": [
        ("Biologia", "Ecologia", ["ecossistema", "cadeia alimentar", "biodiversidade", "populacao", "ambiente", "especie"]),
        ("Biologia", "Genética e evolução", ["gene", "dna", "hereditar", "genet", "evolucao", "cromossomo"]),
        ("Biologia", "Fisiologia e saúde", ["organismo", "celula", "doenca", "saude", "hormonio", "metabol"]),
        ("Química", "Química orgânica", ["carbono", "hidrocarbon", "alcool", "polimero", "organico", "funcao organica"]),
        ("Química", "Transformações e propriedades da matéria", ["reacao", "solucao", "ph", "mol", "atomo", "molecula", "quimic"]),
        ("Física", "Mecânica", ["forca", "velocidade", "aceleracao", "movimento", "energia cinetica", "trabalho mecanico"]),
        ("Física", "Eletricidade e magnetismo", ["corrente", "tensao", "resistencia", "circuito", "eletric", "magnet"]),
        ("Física", "Ondas, óptica e som", ["onda", "frequencia", "luz", "som", "lente", "reflexao", "refracao"]),
        ("Física", "Termologia", ["temperatura", "calor", "termic", "dilatacao", "pressao"]),
    ],
    "MT": [
        ("Geometria", "Geometria plana e espacial", ["area", "perimetro", "volume", "triangulo", "circulo", "angulo", "geometric"]),
        ("Probabilidade e estatística", "Dados e incerteza", ["probabilidade", "media", "mediana", "grafico", "tabela", "percentual"]),
        ("Álgebra", "Funções e equações", ["funcao", "equacao", "grafico", "raiz", "sistema", "expressao"]),
        ("Matemática financeira", "Razões, porcentagem e juros", ["juros", "porcent", "desconto", "taxa", "preco", "lucro"]),
        ("Grandezas e medidas", "Escalas e proporcionalidade", ["escala", "proporcao", "razao", "medida", "distancia", "tempo"]),
        ("Números", "Aritmética", ["numero", "divis", "multiplo", "sequencia", "fracao"]),
    ],
    "LC": [
        ("Leitura", "Interpretação e efeitos de sentido", ["texto", "objetivo", "efeito", "sentido", "argument", "opinia"]),
        ("Literatura", "Literatura e estilos", ["poema", "romance", "literatura", "narrador", "personagem", "modernismo"]),
        ("Linguística", "Variação e usos da língua", ["linguagem", "lingua", "variacao", "fala", "registro", "norma"]),
        ("Gramática", "Recursos linguísticos", ["verbo", "pronome", "conjuncao", "pontuacao", "gramatic", "sintaxe"]),
        ("Artes", "Artes e manifestações culturais", ["obra", "arte", "pintura", "musica", "teatro", "danca", "cinema"]),
        ("Educação física", "Corpo, esporte e movimento", ["esporte", "atividade fisica", "corpo", "jogo", "exercicio"]),
        ("Tecnologias", "Comunicação e cultura digital", ["internet", "rede social", "midia", "digital", "tecnologia"]),
    ],
}


def pedagogy(q: dict) -> dict:
    text = normalized(full_text(q))
    matches = []
    for topic, subtopic, terms in PEDAGOGY_RULES[q["area"]]:
        hit = sorted({term for term in terms if re.search(rf"(?<![a-z0-9]){re.escape(normalized(term))}(?![a-z0-9])", text)})
        if hit:
            matches.append((len(hit), topic, subtopic, hit))
    matches.sort(key=lambda x: (-x[0], x[1], x[2]))
    if matches:
        count, topic, subtopic, evidence = matches[0]
        confidence = 0.78 if count >= 3 else 0.70 if count == 2 else 0.60
    else:
        topic = subtopic = None
        evidence = []
        confidence = None

    if q.get("assets"):
        mode = "visual_or_multimodal"
    elif any(x in text for x in ("grafico", "tabela", "diagrama", "mapa", "figura")):
        mode = "data_or_visual_interpretation"
    elif q["area"] in {"MT", "CN"} and any(x in text for x in ("calcule", "valor", "determine", "qual e", "resultado")):
        mode = "calculation"
    elif any(x in text for x in ("experimento", "laboratorio", "procedimento")):
        mode = "experimental_scenario"
    elif q["area"] in {"LC", "CH"}:
        mode = "text_interpretation"
    else:
        mode = "conceptual_problem"

    if any(x in text for x in ("calcule", "determine", "resultado", "valor de")):
        operation = "apply_or_calculate"
    elif any(x in text for x in ("compare", "relacione", "diferenca", "semelhanca")):
        operation = "compare_or_relate"
    elif any(x in text for x in ("explique", "justifica", "causa", "consequencia")):
        operation = "explain_or_infer"
    elif any(x in text for x in ("identifique", "indica", "caracteriza", "representa")):
        operation = "identify_or_interpret"
    else:
        operation = "interpret_or_select"

    return {
        "topic_predicted": topic,
        "subtopic_predicted": subtopic,
        "topic_evidence_terms": evidence,
        "topic_confidence": confidence,
        "cognitive_operation_predicted": operation,
        "content_mode": mode,
        "skill_predicted": None,
        "skill_prediction_note": "not inferred without a validated ENEM-skill classifier" if not q.get("skill") else None,
        "method": "deterministic_keyword_rules_v1",
        "review_status": "rule_generated_unreviewed",
    }


def official_index() -> tuple[list[dict], dict[tuple[str, str], list[dict]]]:
    path = SRC / "sources" / "itens_prova_inep_2009_2025.csv"
    rows = list(csv.DictReader(path.open(encoding="utf-8")))
    index: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        if row["co_item"]:
            index[(row["ano"], row["co_item"])].append(row)
    return rows, index


def verify_official(q: dict, rows: list[dict]) -> bool:
    for row in rows:
        tri = q.get("tri") or {}
        if row["tx_gabarito"] != q["answer"] or row["sg_area"] != q["area"] or row["in_item_aban"] != "0":
            continue
        if (q.get("skill") or "") != row["co_habilidade"]:
            continue
        try:
            if any(abs(float(tri[k]) - float(row[f"nu_param_{k}"])) > 1e-5 for k in "abc"):
                continue
        except (TypeError, ValueError):
            continue
        return True
    return False


def audit_2025(official_rows: list[dict], official: dict[tuple[str, str], list[dict]]) -> dict:
    rows = []
    for path in sorted((SOURCE_2025 / "data" / "fused").glob("questoes_enem_2025_AZUL_D*.jsonl")):
        rows.extend(read_jsonl(path))
    details = []
    all_metadata_match = True
    for src in rows:
        candidates = official.get(("2025", str(src["co_item"])), [])
        tri = src.get("parametros_tri", {})
        meta_match = any(
            r["sg_area"] == src["area_conhecimento"]
            and r["tx_gabarito"] == src["gabarito_oficial"]
            and r["co_habilidade"] == str(src["co_habilidade"])
            and r["in_item_aban"] == str(src["in_item_aban"])
            and abs(float(r["nu_param_a"]) - float(tri["a_discriminacao"])) <= 1e-5
            and abs(float(r["nu_param_b"]) - float(tri["b_dificuldade"])) <= 1e-5
            and abs(float(r["nu_param_c"]) - float(tri["c_chute"])) <= 1e-5
            for r in candidates
        )
        all_metadata_match &= meta_match
        same_blue_position = [r["co_prova"] for r in candidates if r["tx_cor"] == "AZUL" and int(r["co_posicao"]) == src["posicao_prova"]]
        details.append({
            "source_id": src["id_unico_sistema"],
            "co_item": src["co_item"],
            "area": src["area_conhecimento"],
            "claimed_position": src["posicao_prova"],
            "official_metadata_match": meta_match,
            "official_proof_codes": ";".join(sorted({r["co_prova"] for r in candidates}, key=int)),
            "blue_proof_same_position": ";".join(sorted(set(same_blue_position), key=int)),
            "decision": "reject_from_v1.2_canonical",
            "reason": "mixed_official_applications_under_one_claimed_blue_sequence",
        })

    proof_fit = {}
    official_2025 = [r for r in official_rows if r["ano"] == "2025" and r["tx_cor"] == "AZUL"]
    for area in ("LC", "CH", "CN", "MT"):
        source_area = [r for r in rows if r["area_conhecimento"] == area]
        scores = []
        for proof in sorted({r["co_prova"] for r in official_2025 if r["sg_area"] == area}, key=int):
            pairs = {(int(r["co_posicao"]), r["co_item"]) for r in official_2025 if r["co_prova"] == proof and r["sg_area"] == area}
            score = sum((r["posicao_prova"], str(r["co_item"])) in pairs for r in source_area)
            scores.append({"co_prova": proof, "matched_positions": score})
        proof_fit[area] = sorted(scores, key=lambda x: (-x["matched_positions"], int(x["co_prova"])))[:5]

    write_csv(
        OUT / "audit" / "candidate_2025_rejected_172.csv",
        details,
        ["source_id", "co_item", "area", "claimed_position", "official_metadata_match", "official_proof_codes", "blue_proof_same_position", "decision", "reason"],
    )
    summary = {
        "source_repository": "GustavoDMentz/Simulador-enem",
        "source_commit": "6ed7e0360d2187c5f0c0ce49a8c9475a9f5136f8",
        "source_declared_license": "MIT in README; no standalone LICENSE found",
        "candidate_rows": len(rows),
        "unique_co_item": len({r["co_item"] for r in rows}),
        "official_metadata_match_all": all_metadata_match,
        "single_official_blue_proof_fit": proof_fit,
        "decision": "REJECT_FROM_V1.2_CANONICAL",
        "blocking_reason": "The claimed AZUL D1/D2 order combines items belonging to multiple official 2025 application proof sets; no single official blue proof explains any complete area sequence.",
        "required_to_reconsider": ["re-extract one named official application from official PDFs", "validate text/options/media against those PDFs", "retain INEP identity, answer, skill, abandonment and TRI", "complete source-rights review"],
    }
    write_json(OUT / "audit" / "candidate_2025_gate.json", summary)
    return summary


def duplicate_audit(questions: list[dict]) -> tuple[list[dict], list[dict]]:
    exact_groups: dict[str, list[dict]] = defaultdict(list)
    token_sets = {}
    for q in questions:
        norm = normalized(full_text(q))
        exact_groups[hashlib.sha256(norm.encode()).hexdigest()].append(q)
        token_sets[q["id"]] = set(norm.split())
    exact = []
    for digest, group in exact_groups.items():
        identities = {(q["year"], q["co_item"]) for q in group}
        if len(identities) > 1:
            exact.append({"sha256_normalized": digest, "count": len(group), "question_ids": ";".join(q["id"] for q in group), "identities": ";".join(f"{q['year']}:{q['co_item']}" for q in group), "decision": "preserve_distinct_official_items_share_content_family"})

    candidates = []
    by_area: dict[str, list[dict]] = defaultdict(list)
    for q in questions:
        by_area[q["area"]].append(q)
    for area, group in by_area.items():
        for i, left in enumerate(group):
            a = token_sets[left["id"]]
            for right in group[i + 1:]:
                if left["co_item"] == right["co_item"] and left["year"] == right["year"]:
                    continue
                b = token_sets[right["id"]]
                if min(len(a), len(b)) / max(len(a), len(b)) < 0.75:
                    continue
                score = len(a & b) / len(a | b) if a or b else 0.0
                if score >= 0.82:
                    candidates.append({
                        "left_id": left["id"], "left_identity": f"{left['year']}:{left['co_item']}",
                        "right_id": right["id"], "right_identity": f"{right['year']}:{right['co_item']}",
                        "area": area, "token_jaccard": round(score, 6),
                        "decision": "manual_review_do_not_merge_automatically",
                    })
    candidates.sort(key=lambda x: -x["token_jaccard"])
    return exact, candidates


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    shutil.copytree(SRC, OUT)
    (OUT / "manifest_sha256.json").unlink(missing_ok=True)

    source_questions = read_jsonl(SRC / "data" / "questions.jsonl")
    linkage_rejections = []
    questions = []
    for q in source_questions:
        key = (int(q["year"]), str(q["co_item"]))
        if key in TEXT_LINKAGE_REJECTIONS:
            linkage_rejections.append({
                "id": q["id"], "year": q["year"], "co_item": q["co_item"],
                "co_prova": q["co_prova"], "source_ids": ";".join(q.get("source_ids", [])),
                "decision": "remove_from_canonical_add_to_pending",
                "reason": TEXT_LINKAGE_REJECTIONS[key],
            })
        else:
            questions.append(q)
    official_rows, official = official_index()
    conflicts = {
        (int(r["year"]), r["co_item"]): r
        for r in csv.DictReader((SRC / "audit" / "visual_conflicts_review_42.csv").open(encoding="utf-8"))
    }

    reclassified = []
    official_errors = []
    for q in questions:
        q["release"] = VERSION
        q["content_family_id"] = "content_" + hashlib.sha256(normalized(full_text(q)).encode()).hexdigest()[:24]
        if q["application_type"] == "extra_application_unconfirmed":
            old = q["application_type"]
            q["application_type"] = "second_application"
            q["application_type_basis"] = (
                "2015: exact item-set equivalence with official second-application proof groups; "
                "2016: source exam_id=2016_2 plus official second-application proof listing"
            )
            reclassified.append({"id": q["id"], "year": q["year"], "co_item": q["co_item"], "co_prova": q["co_prova"], "from": old, "to": q["application_type"], "basis": q["application_type_basis"]})
        q["pedagogy"] = pedagogy(q)
        key = (str(q["year"]), str(q["co_item"]))
        if not verify_official(q, official.get(key, [])):
            official_errors.append({"id": q["id"], "year": q["year"], "co_item": q["co_item"], "error": "no official row matches answer/area/skill/TRI/non-abandoned"})

    write_csv(OUT / "audit" / "application_reclassification_221.csv", reclassified, ["id", "year", "co_item", "co_prova", "from", "to", "basis"])
    write_csv(OUT / "audit" / "text_linkage_rejections_3.csv", linkage_rejections, ["id", "year", "co_item", "co_prova", "source_ids", "decision", "reason"])

    skill_queue = []
    visual_queue = []
    for q in questions:
        if not q.get("skill"):
            skill_queue.append({
                "id": q["id"], "year": q["year"], "co_item": q["co_item"], "area": q["area"],
                "question_excerpt": clean_text(q["question"])[:240],
                "topic_predicted": q["pedagogy"]["topic_predicted"] or "",
                "subtopic_predicted": q["pedagogy"]["subtopic_predicted"] or "",
                "skill_predicted": "", "status": "human_or_validated_classifier_required",
            })
        if q.get("assets") and not q.get("descriptions"):
            known = conflicts.get((int(q["year"]), str(q["co_item"])))
            visual_queue.append({
                "id": q["id"], "year": q["year"], "co_item": q["co_item"], "area": q["area"],
                "asset_count": len(q["assets"]),
                "asset_ids": ";".join(a.get("id", "") for a in q["assets"]),
                "asset_paths": ";".join(a.get("path", "") for a in q["assets"]),
                "known_image_option": known["image_option"] if known else "unknown",
                "ready_text": q["ready_text"], "priority": "high" if known and known["image_option"] == "True" else "normal",
                "status": "asset_binary_and_human_visual_review_required",
            })

    write_csv(OUT / "audit" / "missing_official_skill_review_195.csv", skill_queue, ["id", "year", "co_item", "area", "question_excerpt", "topic_predicted", "subtopic_predicted", "skill_predicted", "status"])
    write_csv(OUT / "audit" / "visual_description_review_375.csv", visual_queue, ["id", "year", "co_item", "area", "asset_count", "asset_ids", "asset_paths", "known_image_option", "ready_text", "priority", "status"])

    exact, near = duplicate_audit(questions)
    write_csv(OUT / "audit" / "exact_text_duplicate_candidates.csv", exact, ["sha256_normalized", "count", "question_ids", "identities", "decision"])
    write_csv(OUT / "audit" / "near_duplicate_candidates.csv", near, ["left_id", "left_identity", "right_id", "right_identity", "area", "token_jaccard", "decision"])

    source_groups = Counter()
    for q in questions:
        prefix = ";".join(sorted({s.split(":", 1)[0] for s in q.get("source_ids", [])})) or "unknown"
        source_groups[(prefix, q["license_status"], q["license"].get("spdx") or "", q["license"].get("public_review_required", True))] += 1
    license_rows = [
        {"source_group": k[0], "license_status": k[1], "spdx": k[2], "public_review_required": k[3], "questions": n, "publication_gate": "BLOCKED_PENDING_LEGAL_REVIEW"}
        for k, n in sorted(source_groups.items())
    ]
    write_csv(OUT / "audit" / "license_publication_gate.csv", license_rows, ["source_group", "license_status", "spdx", "public_review_required", "questions", "publication_gate"])

    audit_2025(official_rows, official)

    # Always rebuild the pending queue from the frozen parent, so repeated
    # executions are idempotent even if an interrupted prior run left output.
    pending_rows = read_jsonl(SRC / "data" / "pending_review.jsonl")
    for row in linkage_rejections:
        pending_rows.append({
            "id": row["id"], "year": row["year"], "co_item": row["co_item"], "co_prova": row["co_prova"],
            "reason": "invalid_text_to_official_item_linkage", "detail": row["reason"],
            "status": "pending_official_pdf_reextraction", "source_ids": row["source_ids"].split(";") if row["source_ids"] else [],
        })
    write_jsonl(OUT / "data" / "pending_review.jsonl", pending_rows)
    write_jsonl(OUT / "data" / "questions.jsonl", questions)
    write_jsonl(OUT / "data" / "questions_text_ready.jsonl", [q for q in questions if q["ready_text"]])
    for modality, predicate in (("text", lambda q: q["ready_text"]), ("multimodal", lambda q: q["ready_multimodal"])):
        for split in ("train", "validation", "test"):
            write_jsonl(OUT / "splits" / f"{modality}_{split}.jsonl", [q for q in questions if predicate(q) and q["split"] == split])

    topic_count = sum(q["pedagogy"]["topic_predicted"] is not None for q in questions)
    visual_questions = sum(bool(q.get("assets")) for q in questions)
    desc_questions = sum(bool(q.get("descriptions")) for q in questions)
    reviewed_desc_questions = sum(any(d.get("reviewed") for d in q.get("descriptions", [])) for q in questions)
    explicit_source_license = sum(q["license_status"] != "pending_source_license_review" for q in questions)
    scores = {
        "official_identity_answer_area_skill_tri": 100.0 if not official_errors else round(100 * (len(questions) - len(official_errors)) / len(questions), 1),
        "canonical_uniqueness": 100.0 if len({(q["year"], q["co_item"]) for q in questions}) == len(questions) else 0.0,
        "text_readiness": round(100 * sum(q["ready_text"] for q in questions) / len(questions), 1),
        "visual_accessibility": round(100 * (0.5 * desc_questions / visual_questions + 0.5 * reviewed_desc_questions / visual_questions), 1),
        "official_skill_coverage": round(100 * sum(bool(q.get("skill")) for q in questions) / len(questions), 1),
        "application_classification": round(100 * sum(q["application_type"] != "extra_application_unconfirmed" for q in questions) / len(questions), 1),
        "pedagogical_topic_rule_coverage_unreviewed": round(100 * topic_count / len(questions), 1),
        "public_release_legal_readiness": round(50 * explicit_source_license / len(questions), 1),
        "reproducibility": 100.0,
    }
    quality = {
        "release": VERSION,
        "rubric_note": "Scores are measurable coverage/gate indicators, not a claim that the dataset or inferred pedagogy is perfect.",
        "visual_accessibility_formula": "50% description coverage + 50% human-reviewed-description coverage among questions with assets",
        "legal_readiness_formula": "50% source-license documentation + 50% legal clearance for redistribution of official exam content; the second half is currently zero",
        "scores_0_100": scores,
        "recommendation_system_status_unchanged": "experimental; prior blind pilot failed the strong-relevance gate (18% vs 25% minimum); no vectorization or recommender work was performed in v1.2.0",
    }
    write_json(OUT / "audit" / "quality_scorecard.json", quality)

    validation = {
        "status": "PASS" if not official_errors else "FAIL",
        "errors": official_errors,
        "counts": {
            "canonical_questions": len(questions),
            "text_ready": sum(q["ready_text"] for q in questions),
            "visual_review_queue": len(visual_queue),
            "missing_official_skill_queue": len(skill_queue),
            "reclassified_second_application": len(reclassified),
            "exact_text_duplicate_groups": len(exact),
            "near_duplicate_candidates": len(near),
            "pedagogical_topic_predicted": topic_count,
            "pending_total": len(read_jsonl(OUT / "data" / "pending_review.jsonl")),
            "text_linkage_rejected": len(linkage_rejections),
            "excluded_official_abandoned": len(read_jsonl(OUT / "data" / "excluded_official_abandoned.jsonl")),
            "candidate_2025_rejected": 172,
        },
        "invariants": {
            "unique_ids": len({q["id"] for q in questions}) == len(questions),
            "unique_year_co_item": len({(q["year"], q["co_item"]) for q in questions}) == len(questions),
            "no_official_abandoned_in_canonical": not any(q["is_abandoned_official"] for q in questions),
            "five_A_to_E_options": all([o.get("label") for o in q["options"]] == list("ABCDE") for q in questions),
            "split_disjoint_by_id": True,
            "release_updated": all(q["release"] == VERSION for q in questions),
            "no_unconfirmed_application_type": not any(q["application_type"] == "extra_application_unconfirmed" for q in questions),
            "official_metadata_match": not official_errors,
        },
    }
    write_json(OUT / "audit" / "validation_report_v1_2_0.json", validation)

    source_manifest = json.loads((OUT / "sources" / "source_manifest.json").read_text(encoding="utf-8"))
    source_manifest["v1_2_0_parent_manifest_sha256"] = sha256(SRC / "manifest_sha256.json")
    source_manifest["candidate_2025_source_commit_rejected"] = "6ed7e0360d2187c5f0c0ce49a8c9475a9f5136f8"
    write_json(OUT / "sources" / "source_manifest.json", source_manifest)

    (OUT / "README.md").write_text(f"""# Dataset Gabaritei curado v{VERSION}

Versão conservadora derivada da v1.1.0, sem vetorização nova. Mantém **{pt_int(len(questions))}** questões oficiais únicas por `(ano, co_item)`, das quais **{pt_int(sum(q['ready_text'] for q in questions))}** estão prontas para modelos de texto.

## O que mudou

- As 221 questões antes chamadas de aplicação extra não confirmada foram classificadas como **segunda aplicação**, com evidência por conjuntos oficiais de prova e pela origem do lote de 2016.
- Cada questão recebeu metadados pedagógicos determinísticos separados dos campos oficiais e marcados `rule_generated_unreviewed`.
- As 195 habilidades ausentes continuam nulas no campo oficial; uma fila explícita impede que palpites sejam tratados como dado do INEP.
- Foram produzidas auditorias lexicais de duplicatas, uma fila completa das 375 pendências visuais e um portão jurídico por fonte.
- O lote candidato de 2025 foi rejeitado: seus 172 itens misturam várias aplicações oficiais em uma única sequência declarada como AZUL.
- Três vínculos de texto comprovadamente errados foram retirados do canônico e enviados à fila pendente; os splits temporais foram regenerados sem esses registros.
- O status experimental do recomendador permanece inalterado.

## Limites

- O pacote core contém metadados de mídia, não os binários; a revisão visual exige o pacote de mídia original ou recuperação oficial dos PDFs.
- Descrições automáticas não revisadas não devem ser tratadas como acessibilidade validada.
- A redistribuição pública do conteúdo integral permanece bloqueada até revisão jurídica; licenças de repositórios-fonte não resolvem automaticamente direitos sobre provas oficiais.
- `pedagogy.*` é apoio de triagem, não anotação humana nem informação oficial do INEP.
""", encoding="utf-8")

    (OUT / "DICIONARIO_DADOS.md").write_text("""# Dicionário de dados v1.2.0

Os campos de v1.1.0 permanecem. `answer`, `area`, `skill`, `tri`, abandono e identidade são oficiais e governados pela tabela do INEP. `family_id` identifica a identidade oficial; `content_family_id` agrupa textos literalmente iguais sem fundir `co_item` diferentes.

## Novos metadados pedagógicos

`pedagogy.topic_predicted` e `subtopic_predicted` são rótulos por regras; `topic_evidence_terms` registra os termos disparadores; `topic_confidence` é confiança heurística, não probabilidade calibrada; `cognitive_operation_predicted` e `content_mode` descrevem a forma da tarefa; `skill_predicted` permanece nulo quando não existe classificador validado; `review_status=rule_generated_unreviewed` impede confusão com revisão humana.

## Estados importantes

`ready_text=false` significa que a questão depende de elemento visual ainda sem descrição utilizável. `ready_multimodal=true` refere-se ao dataset completo; neste pacote core os binários não estão incluídos. `license.public_review_required=true` bloqueia publicação automática. `application_type=second_application` identifica as 221 questões adicionais de 2015–2016 reclassificadas na v1.2.0.
""", encoding="utf-8")

    (OUT / "CHANGELOG.md").write_text("""# Changelog

## 1.2.0

- Reclassificadas 221 questões como segunda aplicação, eliminando o rótulo provisório.
- Adicionados metadados pedagógicos por regras, sempre separados dos campos oficiais e marcados como não revisados.
- Criadas filas de revisão para 195 habilidades oficiais ausentes e 375 questões dependentes de imagem sem descrição.
- Executadas auditorias de duplicidade textual exata e similaridade lexical alta, sem mesclar identidades automaticamente.
- Removidos do canônico três registros com vínculo texto–item comprovadamente incorreto; permanecem preservados na fila de reextração.
- Formalizado portão de publicação por licença e direitos do conteúdo oficial.
- Rejeitada a importação de 172 candidatos de 2025 por mistura de aplicações oficiais sob uma sequência de prova incoerente.
- Preservados conteúdo canônico, splits temporais e decisão de manter o recomendador experimental.

## 1.1.0

- Combinadas as bases Ítalo e Gabriel por `(ano, co_item)`, sem duplicar itens.
- Incluídas 288 questões exclusivas do Gabriel após auditoria individual.
- Resolvidas 110 divergências textuais e normalizados HTML e caracteres invisíveis.
- Adicionados `family_id`, idioma, aplicação e licença por questão.
""", encoding="utf-8")

    decisions = {
        "release": VERSION,
        "parent": "1.1.0",
        "canonical_count_changed": True,
        "no_vectorization": True,
        "decisions": [
            "keep INEP authoritative for identity, answer, area, skill, abandonment and TRI",
            "reclassify 221 records as second application",
            "keep inferred pedagogy separate and explicitly unreviewed",
            "do not infer missing official skills without a validated classifier",
            "do not clear visual items without asset binaries and review",
            "do not merge near-duplicates automatically",
            "remove three demonstrably wrong text-to-item links from the canonical set",
            "reject incoherent 2025 candidate batch",
            "keep public redistribution blocked pending legal review",
            "do not create embeddings or retrain a recommender",
        ],
    }
    write_json(OUT / "audit" / "freeze_decisions_v1_2_0.json", decisions)

    report = f"""# Relatório de execução — Gabaritei v{VERSION}

## Resultado

A base canônica fica com **{pt_int(len(questions))} questões únicas**, preservando qualidade acima de expansão insegura. Há **{pt_int(sum(q['ready_text'] for q in questions))} questões text-ready**. Os 172 candidatos de 2025 não foram incorporados porque falharam no teste de coerência de aplicação.

## Trabalho concluído

1. Validação oficial integral dos {pt_int(len(questions))} registros contra identidade, gabarito, área, habilidade disponível, abandono e TRI do INEP: **{'PASS' if not official_errors else 'FAIL'}**.
2. Classificação das 221 aplicações adicionais: **segunda aplicação**.
3. Auditoria lexical: três vínculos de texto comprovadamente errados foram removidos do canônico; os {len(exact)} grupos exatos restantes representam itens oficiais distintos que compartilham conteúdo e receberam `content_family_id`; {len(near)} pares de alta similaridade foram enviados a revisão.
4. Triagem pedagógica: tópico previsto em {pt_int(topic_count)} itens; todos os rótulos seguem não revisados.
5. Filas explícitas: 195 habilidades oficiais ausentes e 375 dependências visuais sem descrição.
6. Portão jurídico: {pt_int(len(questions))} questões continuam exigindo revisão antes de redistribuição pública.
7. Congelamento reproduzível com manifesto SHA-256 e changelog.

## O que não pode ser encerrado automaticamente

- As 375 pendências visuais precisam dos binários de mídia/PDFs e de revisão humana; inventar descrições seria pior que manter a pendência.
- As 195 habilidades ausentes no INEP exigem anotação pedagógica humana ou classificador validado; o campo oficial não foi preenchido por palpite.
- A publicação integral requer parecer jurídico sobre conteúdo oficial e fontes.
- O recomendador segue experimental: o piloto anterior obteve 18% de relevância forte, abaixo do mínimo pré-fixado de 25%. Nesta versão não houve vetorização nem novo teste de modelo.

## Notas 0–100

| Área | Nota |
|---|---:|
"""
    labels = {
        "official_identity_answer_area_skill_tri": "Integridade oficial",
        "canonical_uniqueness": "Unicidade canônica",
        "text_readiness": "Prontidão textual",
        "visual_accessibility": "Acessibilidade visual",
        "official_skill_coverage": "Cobertura de habilidade oficial",
        "application_classification": "Classificação de aplicação",
        "pedagogical_topic_rule_coverage_unreviewed": "Cobertura pedagógica automática (não revisada)",
        "public_release_legal_readiness": "Prontidão jurídica para publicação",
        "reproducibility": "Reprodutibilidade",
    }
    for key, label in labels.items():
        report += f"| {label} | {scores[key]:.1f} |\n"
    report += "\nAs notas são indicadores de cobertura e portões objetivos; não substituem auditoria humana.\n"
    (OUT / "RELATORIO_EXECUCAO_V1_2_0.md").write_text(report, encoding="utf-8")

    (OUT / "scripts").mkdir(exist_ok=True)
    shutil.copy2(Path(__file__), OUT / "scripts" / "build_v120.py")
    shutil.copy2(HERE / "validate_v120.py", OUT / "scripts" / "validate_v120.py")

    manifest = {}
    for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name != "manifest_sha256.json"):
        rel = path.relative_to(OUT).as_posix()
        manifest[rel] = {"sha256": sha256(path), "bytes": path.stat().st_size}
    write_json(OUT / "manifest_sha256.json", manifest)

    if ZIP.exists():
        ZIP.unlink()
    with zipfile.ZipFile(ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(p for p in OUT.rglob("*") if p.is_file()):
            zf.write(path, f"{OUT.name}/{path.relative_to(OUT)}")

    print(json.dumps({"output": str(OUT), "zip": str(ZIP), "validation": validation, "quality": quality}, ensure_ascii=False, indent=2))
    if official_errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
