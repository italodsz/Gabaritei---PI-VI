# Edição core

Esta edição contém dados, splits, auditorias, documentação, fontes e hashes da v1.1.0, mas omite os binários da pasta `media/` para reduzir o tamanho. O catálogo `data/assets.jsonl` foi preservado para manter as referências. Use o pacote completo quando as imagens forem necessárias.
