# Relatório de execução — Gabaritei v1.2.0

## Resultado

A base canônica fica com **3.066 questões únicas**, preservando qualidade acima de expansão insegura. Há **2.691 questões text-ready**. Os 172 candidatos de 2025 não foram incorporados porque falharam no teste de coerência de aplicação.

## Trabalho concluído

1. Validação oficial integral dos 3.066 registros contra identidade, gabarito, área, habilidade disponível, abandono e TRI do INEP: **PASS**.
2. Classificação das 221 aplicações adicionais: **segunda aplicação**.
3. Auditoria lexical: três vínculos de texto comprovadamente errados foram removidos do canônico; os 10 grupos exatos restantes representam itens oficiais distintos que compartilham conteúdo e receberam `content_family_id`; 17 pares de alta similaridade foram enviados a revisão.
4. Triagem pedagógica: tópico previsto em 2.478 itens; todos os rótulos seguem não revisados.
5. Filas explícitas: 195 habilidades oficiais ausentes e 375 dependências visuais sem descrição.
6. Portão jurídico: 3.066 questões continuam exigindo revisão antes de redistribuição pública.
7. Congelamento reproduzível com manifesto SHA-256 e changelog.

## O que não pode ser encerrado automaticamente

- As 375 pendências visuais precisam dos binários de mídia/PDFs e de revisão humana; inventar descrições seria pior que manter a pendência.
- As 195 habilidades ausentes no INEP exigem anotação pedagógica humana ou classificador validado; o campo oficial não foi preenchido por palpite.
- A publicação integral requer parecer jurídico sobre conteúdo oficial e fontes.
- O recomendador segue experimental: o piloto anterior obteve 18% de relevância forte, abaixo do mínimo pré-fixado de 25%. Nesta versão não houve vetorização nem novo teste de modelo.

## Notas 0–100

| Área | Nota |
|---|---:|
| Integridade oficial | 100.0 |
| Unicidade canônica | 100.0 |
| Prontidão textual | 87.8 |
| Acessibilidade visual | 37.9 |
| Cobertura de habilidade oficial | 93.6 |
| Classificação de aplicação | 100.0 |
| Cobertura pedagógica automática (não revisada) | 80.8 |
| Prontidão jurídica para publicação | 34.7 |
| Reprodutibilidade | 100.0 |

As notas são indicadores de cobertura e portões objetivos; não substituem auditoria humana.
