# Changelog

## 1.2.1

- Corrigidos cinco vínculos texto–item e os respectivos vínculos de mídia.
- Corrigido o excesso de cinco imagens anexadas à questão 94 de 2020.
- Recuperadas as três questões que estavam na fila pendente, sem alterar metadados oficiais.
- Adicionados testes de regressão para as posições afetadas.
- Mantido o lote 2025 fora do canônico.
- Nenhuma vetorização ou alteração no recomendador.


## 1.2.0

- Reclassificadas 221 questões como segunda aplicação, eliminando o rótulo provisório.
- Adicionados metadados pedagógicos por regras, sempre separados dos campos oficiais e marcados como não revisados.
- Criadas filas de revisão para 195 habilidades oficiais ausentes e 375 questões dependentes de imagem sem descrição.
- Executadas auditorias de duplicidade textual exata e similaridade lexical alta, sem mesclar identidades automaticamente.
- Removidos do canônico três registros com vínculo texto–item comprovadamente incorreto; permanecem preservados na fila de reextração.
- Formalizado portão de publicação por licença e direitos do conteúdo oficial.
- Rejeitada a importação de 172 candidatos de 2025 por mistura de aplicações oficiais sob uma sequência de prova incoerente.
- Preservados conteúdo canônico, splits temporais e decisão de manter o recomendador experimental.

## 1.1.0

- Combinadas as bases Ítalo e Gabriel por `(ano, co_item)`, sem duplicar itens.
- Incluídas 288 questões exclusivas do Gabriel após auditoria individual.
- Resolvidas 110 divergências textuais e normalizados HTML e caracteres invisíveis.
- Adicionados `family_id`, idioma, aplicação e licença por questão.
