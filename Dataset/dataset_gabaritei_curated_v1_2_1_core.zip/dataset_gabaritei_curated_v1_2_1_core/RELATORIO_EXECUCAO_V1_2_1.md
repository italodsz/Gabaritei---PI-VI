# Relatório de execução — Gabaritei v1.2.1

## Resultado

A auditoria corretiva terminou com **3069 questões canônicas**, **2693 text-ready**, **84 pendências**, **1480 mídias referenciadas** e validação oficial **PASS**.

## O que foi corrigido

| Posição oficial | Correção | Estado |
|---|---|---|
| 2019/178 | Texto e alternativas do comerciante ligados ao gráfico correto | Multimodal; aguarda transcrição quantitativa humana |
| 2019/179 | Questão dos sensores reconstruída com gráfico e planta | Canônica e text-ready com descrição não revisada |
| 2020/91 | Tirinha de eletricidade estática reconstruída | Canônica e text-ready com descrição não revisada |
| 2020/93 | Bateria/amperímetro reconstruída com cinco alternativas visuais | Canônica e text-ready com descrições não revisadas |
| 2020/94 | Removidas cinco imagens que pertenciam à questão 93 | Canônica |
| 2020/5-inglês | Texto de Americanah restaurado, separado da alternativa espanhola | Canônica e text-ready |

## Decisões preservadas

- O INEP governa identidade e metadados oficiais.
- 2025 não entra enquanto a aplicação oficial não for reconstruída de modo coerente.
- Licença de repositório-fonte não equivale a autorização automática para redistribuir provas.
- O recomendador segue experimental; esta versão não vetoriza nem treina modelos.

## Indicadores 0–100

| Indicador | Nota |
|---|---:|
| Integridade oficial | 100.0 |
| Unicidade canônica | 100.0 |
| Prontidão textual | 87.7 |
| Acessibilidade visual | 37.9 |
| Cobertura de habilidade oficial | 93.6 |
| Classificação de aplicação | 100.0 |
| Cobertura pedagógica automática (não revisada) | 80.8 |
| Prontidão jurídica para publicação | 0.0 |
| Reprodutibilidade | 100.0 |

As notas medem cobertura e portões objetivos; não significam perfeição nem validação humana integral.
