# Dataset Gabaritei curado v1.2.1

Versão corretiva derivada da v1.2.0. Contém **3.069 questões oficiais únicas** por `(ano, co_item)`, com **2.693 text-ready**.

## Correções desta versão

- Reconstruídos cinco itens cujo texto havia sido deslocado para a identidade oficial vizinha: 2019/178, 2019/179, 2020/91, 2020/93 e 2020/5-inglês.
- Removidas de 2020/94 cinco figuras de circuitos que pertenciam a 2020/93.
- Preservados gabarito, área, habilidade, abandono e TRI oficiais do INEP.
- A questão 2019/178 continua multimodal, mas não text-ready, até revisão humana da leitura quantitativa do gráfico.
- Os 172 candidatos de 2025 permanecem fora do canônico por mistura de aplicações oficiais.
- Não houve vetorização, embeddings, treino ou novo teste do recomendador.

## Limites

Descrições visuais desta correção foram verificadas contra as imagens, porém não são revisão humana. A publicação pública do conteúdo integral permanece bloqueada até revisão de direitos e fontes. O pacote core contém metadados; os binários estão no pacote de mídia separado.
